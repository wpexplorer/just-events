{
	"extends": [ "plugin:@wordpress/eslint-plugin/recommended" ]
}